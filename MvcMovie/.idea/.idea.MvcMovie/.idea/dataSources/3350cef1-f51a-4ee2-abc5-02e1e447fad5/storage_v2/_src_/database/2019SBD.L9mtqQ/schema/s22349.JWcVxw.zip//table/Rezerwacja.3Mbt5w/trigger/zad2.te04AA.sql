CREATE TRIGGER zad2
ON Rezerwacja FOR DELETE
AS BEGIN
DECLARE @IdRezerwacja INT;
SELECT @IdRezerwacja = deleted.IdRezerwacja
FROM deleted;

IF EXISTS (SELECT 1 FROM Rezerwacja WHERE IdRezerwacja = @IdRezerwacja AND DataDo = 2008)
BEGIN
RAISERROR ('Nie mozna deleted', 16, 1);
END

IF EXISTS (SELECT 1 FROM Rezerwacja WHERE IdRezerwacja = @IdRezerwacja AND Zaplacona = 0)
BEGIN
RAISERROR ('Nie mozna deleted', 16, 1);
END

END;
go

