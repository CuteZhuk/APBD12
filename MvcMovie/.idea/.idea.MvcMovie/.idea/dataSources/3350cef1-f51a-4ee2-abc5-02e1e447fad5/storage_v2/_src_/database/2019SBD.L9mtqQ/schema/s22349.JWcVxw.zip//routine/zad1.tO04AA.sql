CREATE PROCEDURE zad1 (@Nazwa VARCHAR(30), @Imie VARCHAR(30), @Nazwisko VARCHAR(30), @DataOd DATETIME, @DataDo DATETIME)
AS BEGIN
DECLARE @IdPokoju INT;
DECLARE @NrPokoju INT;
DECLARE @Zaplacona VARCHAR(1);

IF NOT EXISTS (SELECT 1 FROM Kategoria WHERE Nazwa = @Nazwa)
BEGIN
RAISERROR ('BRAK', 16, 1);
RETURN
END

DECLARE @Gosc INT;
SELECT @Gosc = @Gosc
FROM Gosc
WHERE Imie = @Imie AND Nazwisko = @Nazwisko;

SELECT @IdPokoju = MIN (@IdPokoju)
FROM Pokoj
WHERE IdKategoria = @Nazwa;

DECLARE @IdGosc INT;
IF @IdGosc IS NULL
BEGIN
INSERT INTO Gosc (Imie, Nazwisko)
VALUES (@Imie, @Nazwisko);
SELECT @IdGosc = SCOPE_IDENTITY();
END

INSERT INTO Rezerwacja (DataOd, DataDo, NrPokoju, Zaplacona, IdGosc)
VALUES (@DataOd, @DataDo, @NrPokoju, @Zaplacona, @IdGosc);

END;
go

